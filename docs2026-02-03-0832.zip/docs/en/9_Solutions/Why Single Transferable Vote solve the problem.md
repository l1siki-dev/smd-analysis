Single Transferable Vote (STV) fixes the system by not only changing the *math*, but also changing the *incentives*.

### 1. Solves "Small Party Loses Before Vote" (The Cost of Entry)
*   **The Mechanism:** Instead of 100 small districts, we combine them into fewer, larger "Multi-Member Districts" (electing 3–5 people).
*   **The Fix:** A party no longer needs enough money to fight 100 individual battles. They don't need 51% of the vote to win; they only need about 15–20% (the "quota") to win *one* of the five seats.
*   **Result:** Diversity of thought is mathematically guaranteed without requiring massive capital.

### 2. Solves "Radicalization" (By cooperation incentive)
*   **The Mechanism:** Voters don't just pick one winner; they **Rank** candidates (1, 2, 3...). If your #1 choice loses, your vote *transfers* to your #2.
*   **The Fix:** This destroys the "Divide and Conquer" strategy. To win, a candidate often needs "transfer votes" from other parties. If a candidate is radical or attacks their neighbors, they get zero transfer votes and lose.
*   **Result:** Politicians are forced to compete on being the "most acceptable," not the "loudest."

### 3. Solves "Categorization is Manipulation" (Prevent gerrymandering)
*   **The Mechanism:** Moving lines matters when it is "Winner Take All." In STV, the district reflects the *proportions* of the people inside it.
*   **The Fix:** You cannot "crack" or "pack" voters easily because 5 seats will naturally capture both the majority and the minority view within that shape.
*   **Result:** The precise location of the border stops mattering. The power returns to the voter, not the map-maker.

### 4. Solves "The Trap of the Local Hero"
*   **The Mechanism:** You vote for a person, not a party list, but within a larger region.
*   **The Fix:** The representative is still local enough to be accountable, but their district is large enough that they must campaign on **National Issues**, not just local "pork barrel" promises.
*   **Result:** Representatives go to parliament with a mandate for policy, not just a mandate to fix local potholes.

### 5. Solves "The Local Monopoly" ("Local Voice" will be heard)
*   **The Mechanism:** Instead of one representative, who will be ignored in the parliament, "owning" your district, multiple politicians (3–5) compete to represent your region.
*   **The Fix:** Competition creates accountability. In the old system, a "Safe Seat" politician could ignore your specific town's problem because they had no rivals. In STV, if one politician ignores your town, a challenger will champion your cause to steal your vote.
*   **Result:** Your local voice is actually *amplified*. You go from having one "Local Hero" who can take you for granted, to a team of representatives fighting for your attention. And all of them become expert of your problem, and they will be sent to the parliament. The likelihood of fixing your local problem will be raised.
