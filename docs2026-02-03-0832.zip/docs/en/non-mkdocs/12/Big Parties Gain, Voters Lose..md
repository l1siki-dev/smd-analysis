##### Winner
- **Big Parties** (They can manipulate how divide voters)
# Loser
- Small Parties (They will be undermined)
- Voters (vote loss influence)