##### Winner
- **Big Parties** (Their loss against the local politician became less impactful)
# Loser
- Local Communities (Their victory becomes irrelevant)
- Voters (vote loss influence)