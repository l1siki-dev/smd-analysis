##### Winner
- **Big Parties** (competitors lose before the game)
# Loser
- Small Party (lose before the game)
- Voters (votes loss influence, they are forced to choice big parties to win)