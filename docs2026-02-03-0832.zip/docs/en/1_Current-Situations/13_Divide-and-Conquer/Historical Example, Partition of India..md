[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)[](Divide%20and%20Conquer%20by%20SMD.md)### Categorized Voters and Radicalization
We can see the extreme danger of this mechanism by looking at the Partition of India. This historical tragedy was fueled by "categorized voters".

When voters were categorized (conflicting interests with other categories), candidates were forced to prove they were the "most faithful" to their specific group. Moderate voices were seen as weak. The system incentivized "outbidding," where candidates became increasingly radical to win.

The result was not a parliament of diverse voices working together; it was a "Radicals vs. Radicals" cage match that ultimately tore the country apart.

The only difference between the India Partition and SMD is the granular size of categorization.

### Categorization as a Trap
The chaos was a deliberate trap Britain left when it "freed" India. 
Britain wanted to tell a story: "When we left India, the chaos started. We are a good force of stability."
It was Divide and Conquer, the exact strategy that Britain employed to conquer India. When they left, they used it again.

Single-Member Districts apply this same Divide and Conquer with "categorized voters" logic, but instead of dividing into a few blobs, it divides into fragmented **numerous local identities**. Which leads to them having no real power. 

Local categories push voters toward **local first**. Voters are incentivised to choose the candidate who is most radically obsessed with their specific district.

However, this renderer that the representative irrelevant on the national stage. The more radical they are, the more difficult to make friends at the national level. 