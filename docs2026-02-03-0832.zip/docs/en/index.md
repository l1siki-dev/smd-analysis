# Why We Should Think About Our Current Election System Now

1. Because it shapes our daily life. Tax, economic policy, society, basically everything is affected by politics. And elections shape politics.
2. Because the current system is not good for you. It is often designed for politicians' survival. Not your survival.
3. Because if we demand the change, politicians have to implement the change. We can change the outcome. If we acknowledge the current situation and act.
4. Because it's a good time to act. The Internet and SNS enabled mass information sharing, bypassing "authority". 
5. Because we should act before things become too late. Elites are re-shaping the Internet for themselves. AI likely change our society forever. Thus, we are living in possibly the most important era of humanity. What is decided today could persist long time and affect an unimaginable number of people.  
6. And, Japan (my country) seems to be entering a political transition. the long standing party might finally open the path for others. It's time to recap our system. And see what is happening, what is the election, how our election system shapes our politics. And what system do you want? What society do you want to live in?

Let's Start.
We will finish everything in 10 minutes.